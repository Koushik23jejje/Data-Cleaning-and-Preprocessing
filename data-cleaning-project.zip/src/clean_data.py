import pandas as pd
import os

# Paths
INPUT_PATH = 'data/raw_dataset.csv'
OUTPUT_PATH = 'output/cleaned_dataset.csv'

# Create output directory if it doesn't exist
os.makedirs('output', exist_ok=True)

# Load the dataset
df = pd.read_csv(INPUT_PATH)

# Drop rows with missing values (or you can use fillna for imputation)
df = df.dropna()

# Remove duplicate rows
df = df.drop_duplicates()

# Standardize date format if 'date' column exists
if 'date' in df.columns:
    df['date'] = pd.to_datetime(df['date'], errors='coerce')

# Normalize categorical column 'gender' if exists
if 'gender' in df.columns:
    df['gender'] = df['gender'].str.strip().str.lower()

# Save the cleaned dataset
df.to_csv(OUTPUT_PATH, index=False)

print(f"✅ Cleaned data saved to: {OUTPUT_PATH}")
