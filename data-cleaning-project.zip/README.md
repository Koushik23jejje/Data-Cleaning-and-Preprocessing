# 🧹 Data Cleaning and Preprocessing Project

This project performs data cleaning and preprocessing on a raw dataset using **Python** and **pandas**.

## 📂 Project Structure

```
data/
  raw_dataset.csv           # Raw input data
output/
  cleaned_dataset.csv       # Cleaned dataset
src/
  clean_data.py             # Main cleaning script
```

## 🔧 Tasks Performed

- Load raw dataset
- Identify and handle missing values (drop/impute)
- Remove duplicate rows
- Standardize inconsistent formats:
  - Dates (`datetime`)
  - Categorical text (e.g., gender casing)

## 🚀 How to Run

```bash
# 1. Clone the repo
git clone https://github.com/yourusername/data-cleaning-project.git
cd data-cleaning-project

# 2. Install requirements
pip install -r requirements.txt

# 3. Run the cleaning script
python src/clean_data.py
```

## 🛠 Tools Used

- Python
- pandas

## 📄 License

MIT License
